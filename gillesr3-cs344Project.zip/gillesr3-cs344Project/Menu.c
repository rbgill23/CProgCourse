/* Title	: Report View Project Menu File*/
/* File		: Menu.c		*/  
/* Date		: 4/25/2016		*/
/* Author	: Russell Gillespie	*/
/* Course	: CS 344		*/
/* Section	: 04			*/
/* Assignment	: Course Project	*/
/* Input	: from keyboard		*/
/* Output	: to screen		*/
/* Method	: none			*/
#include <stdio.h>


/* main menu for Report View*/
int Menu (){
int MenuChoice;
printf("\n\t%s\n\t%s\n\t%s\n\t%s\n\t%s","Report View Main Menu","1) Display All Reports",
	"2) Display Employee Report ","3) Quit",
		"Enter a corresponding Menu number: ");
	scanf("%d", &MenuChoice);
return MenuChoice;
}
