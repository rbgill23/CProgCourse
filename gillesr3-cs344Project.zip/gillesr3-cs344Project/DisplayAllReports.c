/* Title	: Report View Project Display All File*/
/* File		: DisplayAllReports.c		*/  
/* Date		: 4/25/2016		*/
/* Author	: Russell Gillespie	*/
/* Course	: CS 344		*/
/* Section	: 04			*/
/* Assignment	: Course Project	*/
/* Input	: from keyboard		*/
/* Output	: to screen		*/
/* Method	: allocating memory, linked list*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "action.h"

/* Function to display all the reports in the specified file */
void DisplayAllReports(Report *startPtr, Report *currentPtr, char *argv[]){
FILE *gfPtr;
/*check for and open group file*/
if ((gfPtr=fopen(argv[2],"r"))==NULL){
printf("\tFile %s is not found.\n", argv[2]);}
else{
currentPtr=startPtr=(ReportPtr) malloc(sizeof(Report));
/*run through file till end to display all reports*/
printf("\t%s\t%s\t%s\t%s\n", "Time","Employee ID", "Location", "Comments");
while(4==fscanf(gfPtr,"%4s%6s%2s%[^\n]%*c", currentPtr->time,currentPtr->empID,currentPtr->location,currentPtr->comment)){
printf("\t%s\t%s\t\t%s\t\t%s\n",currentPtr->time,currentPtr->empID,currentPtr->location,currentPtr->comment);
currentPtr->nextPtr=(ReportPtr) malloc(sizeof(Report));
currentPtr=currentPtr->nextPtr;
}
currentPtr->nextPtr=NULL;
fclose(gfPtr);
}
}/*end display all function*/
