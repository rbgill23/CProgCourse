/* Title	: Report View Project Employee Reports File*/
/* File		: EmployeeReports.c	*/  
/* Date		: 4/25/2016		*/
/* Author	: Russell Gillespie	*/
/* Course	: CS 344		*/
/* Section	: 04			*/
/* Assignment	: Course Project	*/
/* Input	: from keyboard		*/
/* Output	: to screen		*/
/* Method	: allocating memory, linked list*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "action.h"

/* Function to display specific employee reports */
void EmployeeReports(Report *startPtr, Report *currentPtr, char *argv[]){
char fempID[7];
int startTime[4];
int TotStart=0;/*conversion of startTime(an array) to single int*/
int endTime[4];
int TotEnd=0;/*conversion of endTime(an array) to single int*/
int i,j; /*temp variables*/

j=0;
/* check for employee ID*/
while (j==0){

 	printf("\tEnter Employee ID: ");
	scanf(" %6s%*c", fempID);
	printf("\tIs this the correct Employee ID: %s ?\n", fempID);
	printf("\tEnter 1 for YES, 0 for NO: ");
	scanf("%d",&j);
}/* end while employee ID loop*/
	
j=0;
/* check start time */
while(j==0){
printf("\tEnter the start time: ");
scanf("%1d%1d%1d%1d%*c", &startTime[0], &startTime[1], &startTime[2], &startTime[3]);
	if (startTime[0]==2 && startTime[1]>3|| startTime[0]>2 || startTime[2]>5)
	{
	printf("\tERROR with Start Time.\nTry Again.\n");
	}
	else{
	printf("\tIs this the correct Start Time: %d%d%d%d ?\n",startTime[0], startTime[1], 
		startTime[2], startTime[3] );
	printf("\tEnter 1 for YES, 0 for NO: ");
	scanf("%d", &j);
	}
}/* end while start time loop*/
j=0;
/* check end time*/
while(j==0){
printf("\tEnter the end time: ");
scanf("%1d%1d%1d%1d%*c", &endTime[0], &endTime[1], &endTime[2], &endTime[3]);
	if (endTime[0]==2 && endTime[1]>3 || endTime[0]>2 || endTime[2]>5)
	{
	printf("\tERROR with End Time.\nTry Again.\n");
	}
	else{
	printf("\tIs this the correct End Time: %d%d%d%d ?\n",endTime[0], endTime[1], 
		endTime[2], endTime[3] );
	printf("\tEnter 1 for YES, 0 for NO: ");
	scanf("%d", &j);
	}
} /* end while end time loop*/

/* combining start and end times*/
for (i=0;i<4;i++){
	TotStart=(TotStart*10)+startTime[i];
	TotEnd=(TotEnd*10)+endTime[i];
} /*end for*/

FILE *gfPtr; 
/*check for and open groupfile*/
if ((gfPtr=fopen(argv[2],"r"))==NULL){
printf("\tFile %s is not found\n", argv[2]);
}
else {
currentPtr=startPtr=(ReportPtr) malloc(sizeof(Report));
printf("\t%s\t%s\t%s\t%s\n", "Time","Employee ID", "Location", "Comments");
/*while statement runs through file till end of file*/
while(4==fscanf(gfPtr,"%4s%6s%2s%[^\n]%*c", currentPtr->time,currentPtr->empID,currentPtr->location,currentPtr->comment)){
/*if statement comparing employee IDs*/
if (strcmp(fempID,currentPtr->empID)==0){
	/*if statement comparing start and end times with report time*/
	if(atoi(currentPtr->time)>=TotStart&&atoi(currentPtr->time)<=TotEnd){
		printf("\t%s\t%s\t\t%s\t\t%s\n",currentPtr->time,
			currentPtr->empID,currentPtr->location,currentPtr->comment);
	
	} /* end if*/
	
}/*end if*/
currentPtr->nextPtr=(ReportPtr) malloc(sizeof(Report));
currentPtr=currentPtr->nextPtr; /*on to the next report*/
}/*end while*/
currentPtr->nextPtr=NULL;
free(currentPtr);
fclose(gfPtr);
}
} /* end EmployeeReports function*/
