/* Title	: Report View Project Header File*/
/* File		: action.h		*/  
/* Date		: 4/25/2016		*/
/* Author	: Russell Gillespie	*/
/* Course	: CS 344		*/
/* Section	: 04			*/
/* Assignment	: Course Project	*/
/* Input	: from keyboard		*/
/* Output	: to ReportView.c 	*/
/* Method	: none	 		*/


#ifndef ACTION_H_
#define ACTION_H_

struct reportData  {
char time[5];
char empID[7];
char location[3];
char comment[51];
struct reportData *nextPtr;
};
typedef struct reportData Report;
typedef Report *ReportPtr;
/* Display Main Menu */
int Menu();
/* Function to display all the records in the specified file */
void DisplayAllReports(Report *startPtr, Report *currentPtr, char *argv[]);
/* Function to display specific employee reports */
void EmployeeReports(Report *startPtr, Report *currentPtr, char *argv[]);
/* Function to move text file info to bin file*/
void ToBinFile(Report *startPtr, Report *currentPtr, char *argv[]);
#endif
