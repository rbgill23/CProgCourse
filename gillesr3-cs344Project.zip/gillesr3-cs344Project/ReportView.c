/* Title	: Report View Project Main File	*/
/* File		: ReportView.c		*/  
/* Date		: 4/25/2016		*/
/* Author	: Russell Gillespie	*/
/* Course	: CS 344		*/
/* Section	: 04			*/
/* Assignment	: Course Project	*/
/* Input	: from keyboard		*/
/* Output	: to screen, to bin file */
/* Method	: arithmetic 		 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "action.h"


int main(int argc, char* argv[]){

Report *startPtr, *currentPtr;
startPtr=currentPtr=NULL;
int MenuChoice=0;
if (argc>3){printf("Too many arguments on the command line.\nClosing the program.\n");exit(0);}
if (argc<2){printf("Too few arguments on the command line.\nClosing the program.\n");exit(0);}
printf("\n\tWelcome to Report View!\n\tUse the main menu to navigate the group file and to display reports.\n");
/*Menu Options*/
while (MenuChoice!=3){
	
MenuChoice=Menu();

	switch (MenuChoice) {
	case 1:
		/* Function to display all the reports in the specified file */
		DisplayAllReports(startPtr, currentPtr, argv);
		break;
	case 2:
		/* Function to display specific employee reports */
		EmployeeReports(startPtr, currentPtr, argv);

		break;
	case 3:
		printf("\tWriting to %s file.\n",argv[1]);
		printf("\tClosing program.\n");
		/* Function to move text file info to bin file*/
		ToBinFile(startPtr, currentPtr, argv);
		exit(0);
		break;
	default:
		printf("\nIncorrect Menu number. Try again.\n");
	} /*end switch menu*/
} /*end while menu*/

return 0;
} /*end main*/







