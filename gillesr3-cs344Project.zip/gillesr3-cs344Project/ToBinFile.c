/* Title	: Report View Project Print to Binary File*/
/* File		: ToBinFile.c		*/  
/* Date		: 4/25/2016		*/
/* Author	: Russell Gillespie	*/
/* Course	: CS 344		*/
/* Section	: 04			*/
/* Assignment	: Course Project	*/
/* Input	: from keyboard		*/
/* Output	: to daily list binary file*/
/* Method	: allocating memory, linked list*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "action.h"

/* Function to move text file info to bin file*/
void ToBinFile(Report *startPtr, Report *currentPtr, char *argv[]){

FILE *gfPtr; /*point to group file*/
FILE *dfPtr; /*point ot daily list file*/
if ((dfPtr=fopen(argv[1],"ab"))==NULL){
printf("\tFile %s is not found.\n", argv[1]);}
else {
if ((gfPtr=fopen(argv[2],"r"))==NULL){
printf("\tFile %s is not found.\n", argv[2]);}
else {

currentPtr=startPtr=(ReportPtr) malloc(sizeof(Report));
/*run through group file and copy to daily list file*/
while(4==fscanf(gfPtr,"%4s%6s%2s%[^\n]%*c", currentPtr->time,currentPtr->empID,currentPtr->location,currentPtr->comment)){
fprintf(dfPtr,"%s%s%s%s\n",currentPtr->time,currentPtr->empID,currentPtr->location,currentPtr->comment);
currentPtr->nextPtr=(ReportPtr) malloc(sizeof(Report));
currentPtr=currentPtr->nextPtr;
}/*end while*/
currentPtr->nextPtr=NULL;
free(currentPtr);
fclose(gfPtr);
fclose(dfPtr);
}}
}/* end function*/
